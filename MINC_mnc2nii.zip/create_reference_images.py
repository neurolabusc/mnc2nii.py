#!/usr/bin/env python3

import os
import subprocess
import sys

# Define input and output folders
ORIGINAL_DIR = "./Original"
IN_DIR = "./In"
REF_DIR = "./Ref"
MINC1_DIR = "./Minc1"

# Ensure output directories exist
for folder in [IN_DIR, REF_DIR, MINC1_DIR]:
    os.makedirs(folder, exist_ok=True)

def run_command(command):
    """Run a shell command and handle errors."""
    try:
        subprocess.run(command, check=True, shell=True)
        print(f"Success: {command}")
    except subprocess.CalledProcessError as e:
        print(f"Error: {command}\n{e}")
        sys.exit(1)

def convert_nifti_to_mnc():
    """Step 1: Convert NIfTI to MINC using nii2mnc."""
    nii_files = [f for f in os.listdir(ORIGINAL_DIR) if f.endswith('.nii')]
    if not nii_files:
        print("No NIfTI files found in the 'Original' folder.")
        return

    for nii_file in nii_files:
        input_path = os.path.join(ORIGINAL_DIR, nii_file)
        output_path = os.path.join(IN_DIR, os.path.splitext(nii_file)[0] + '.mnc')
        run_command(f"nii2mnc {input_path} {output_path}")

def convert_mnc_to_nii():
    """Step 2: Convert MINC to NIfTI using mnc2nii."""
    mnc_files = [f for f in os.listdir(IN_DIR) if f.endswith('.mnc')]
    if not mnc_files:
        print("No MINC files found in the 'In' folder.")
        return

    for mnc_file in mnc_files:
        input_path = os.path.join(IN_DIR, mnc_file)
        output_path = os.path.join(REF_DIR, os.path.splitext(mnc_file)[0] + '.nii.gz')
        run_command(f"mnc2nii {input_path} {output_path}")

def convert_mnc_to_minc1():
    """Step 3: Convert MINC2 to MINC1 using mincconvert."""
    mnc_files = [f for f in os.listdir(IN_DIR) if f.endswith('.mnc')]
    if not mnc_files:
        print("No MINC files found in the 'In' folder.")
        return

    for mnc_file in mnc_files:
        input_path = os.path.join(IN_DIR, mnc_file)
        output_path = os.path.join(MINC1_DIR, mnc_file)
        run_command(f"mincconvert -clobber -2 {input_path} {output_path}")

def main():
    """Main pipeline for conversion."""
    print("Starting conversion pipeline...")
    convert_nifti_to_mnc()
    convert_mnc_to_nii()
    convert_mnc_to_minc1()
    print("Conversion pipeline completed successfully.")

if __name__ == "__main__":
    main()
