# mnc2nii.py
convert MINC format images to NIfTI

```
mnc2nii/
├── __init__.py
└── converter.py
```
# Links

 - [nii2mnc](https://bic-mni.github.io/man-pages/man/nii2mnc.html) command line tool to convert NIfTI images to MINC (e.g. `Original`->`In`)
 - [mnc2nii](https://bic-mni.github.io/man-pages/man/mnc2nii.html) reference command line tool to convert MINC images to NIfTI (e.g. `In`->`Ref`)
 - [mincconvert](https://bic-mni.github.io/man-pages/man/mincconvert.html) command line tool for converting between MINC1 (netcdf) and MINC2 (HDF5) formats.
 - [minc2.py](https://github.com/nipy/nibabel/blob/84294f4e05e0f10f9cc64d3474f94ad3e243f682/nibabel/minc2.py#L144) nibabel Python class for reading MINC2 (HDF5) images.
 - [minc1.py](https://github.com/nipy/nibabel/blob/84294f4e05e0f10f9cc64d3474f94ad3e243f682/nibabel/minc1.py) nibabel Python class for reading MINC1 (netcdf) images.
 